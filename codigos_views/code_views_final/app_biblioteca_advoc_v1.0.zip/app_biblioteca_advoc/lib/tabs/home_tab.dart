import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'dart:async';

import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:transparent_image/transparent_image.dart';

class HomeTab extends StatelessWidget {

  @override
  Widget build(BuildContext context) {



    Widget _buildBodyBack() => Container( // Essa função foi criada para fazer um background em degradê
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [
              Color.fromARGB(255, 211, 118, 130),
              Color.fromARGB(255, 253, 181, 168),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight
        ),
      ),
    );


    return Stack( // Usado para colocar coisas uma em cima da outra (sobreposição)
      children: <Widget>[
        _buildBodyBack(), // Chamando a função do Background degradê criado
        CustomScrollView(
          slivers: <Widget>[
            SliverAppBar( // Essa é a configuração de uma AppBar personalizada que permite com que ela desça juntamente com o conteúdo após o usuário deslizar a página
              floating: true, // Flutuante, transforma a appBar em flutuante e faz com que a barra desapareça quando desliza
              snap:  true, // A barra reaparece quando não está deslizando
              backgroundColor: Colors.transparent, // Background transparente
              elevation: 0.0, // Colocando a barra no mesmo plano do conteúdo da página, sem deixar sombras
              flexibleSpace: FlexibleSpaceBar(
                title: const Text("Biblioteca"),
                centerTitle: true,
              ),
            ),
                FutureBuilder<QuerySnapshot>(
                  future: Firestore.instance.collection("home").orderBy("pos").getDocuments(),
                  builder: (context, snapshot){
                    if(!snapshot.hasData)
                      return SliverToBoxAdapter(
                        child: Container(
                          height: 200,
                          alignment: Alignment.center,
                          child: CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        ),
                      );
                    else {
                      return SliverStaggeredGrid.count(
                        crossAxisCount: 2,
                        mainAxisSpacing: 1.0,
                        crossAxisSpacing: 1.0,
                        staggeredTiles: snapshot.data.documents.map(
                            (doc){
                              return StaggeredTile.count(doc.data["x"], doc.data["y"]);
                            }
                        ).toList(),
                        children: snapshot.data.documents.map(
                            (doc){
                              return FadeInImage.memoryNetwork(
                                  placeholder: kTransparentImage,
                                  image: doc.data["imagens"],
                                fit: BoxFit.cover,
                              );
                            }
                        ).toList(),
                      );
                    }
                  },
                )

                    ]
                )
          ],
        );


  }
}
