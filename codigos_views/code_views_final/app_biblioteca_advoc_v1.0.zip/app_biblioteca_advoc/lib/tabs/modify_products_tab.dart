import 'package:appbibliotecaadvoc/tiles/category_tile.dart';
import 'package:appbibliotecaadvoc/tiles/modify_category_tile.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ModifyProductsTab extends StatefulWidget {

  ModifyProductsTab();

  @override
  _ModifyProductsTabState createState() => _ModifyProductsTabState();
}

class _ModifyProductsTabState extends State<ModifyProductsTab> with AutomaticKeepAliveClientMixin{
  @override
  Widget build(BuildContext context) {
    super.build(context);
    return FutureBuilder<QuerySnapshot>(
      future: Firestore.instance.collection("produtos").getDocuments(),
      builder: (context, snapshot){
        if(!snapshot.hasData) return Center(
          child: CircularProgressIndicator(),
        );
        return ListView.builder(
            itemCount: snapshot.data.documents.length,
            itemBuilder: (context, index){
              return ModifyCategoryTile(snapshot.data.documents[index]);
            });
      },
    );
  }

  @override
  bool get wantKeepAlive => true;
}
