import 'package:appbibliotecaadvoc/tiles/home_tile.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class SearchData extends SearchDelegate<String>{

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton( // Botão para limpar o campo de pesquisa
        icon: Icon(Icons.clear),
        onPressed: (){
          query = "";
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: (){
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Container();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Container();
  }

//  suggestions(String search) async {
//    FutureBuilder<QuerySnapshot>(
//      future: Firestore.instance.collection("produtos").getDocuments(),
//      builder: (context, snapshot) {
//        if (!snapshot.hasData)
//          return Container(
//              height: 200.0,
//              child: Center(
//                child: CircularProgressIndicator(),));
//        else {
//          return ListView(
//            children: snapshot.data.documents.map((doc){
//              return HomeTile();
//            }).toList(),
//          );
//        }
//      },
//    );
//  }

}