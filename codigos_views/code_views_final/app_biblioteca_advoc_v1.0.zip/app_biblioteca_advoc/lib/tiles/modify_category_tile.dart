import 'package:appbibliotecaadvoc/datas/product_data.dart';
import 'package:appbibliotecaadvoc/screens/modify_products_screen.dart';
import 'package:appbibliotecaadvoc/tiles/category_tile.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ModifyCategoryTile extends StatelessWidget {

  final DocumentSnapshot category;

  ModifyCategoryTile(this.category);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Card(
        child: ExpansionTile(
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).primaryColor,
            child: Icon(Icons.book, color: Colors.grey[850], ),
          ),
          title: Text(
            category.data["title"],
            style: TextStyle(color: Colors.grey[850], fontWeight: FontWeight.w500),
          ),
          children: <Widget>[
            FutureBuilder<QuerySnapshot>(
              future: category.reference.collection("items").getDocuments(),
              builder: (context, snapshot){
                if(!snapshot.hasData) return Container();
                return Column(
                  children: snapshot.data.documents.map((doc){
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundImage: NetworkImage(doc.data["imagem"][0]),
                        backgroundColor: Colors.transparent,
                      ),
                      title: Text(doc.data["titulo"]),
                      onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => ModifyProductsScreen(
                          categoryId: category.documentID,
                          product: doc,
                        )));
                      },
                    );
                  }).toList()..add( // ..add serve para adicionar mais um widget (formato cascata)
                    ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.transparent,
                        child: Icon(Icons.add, color: Colors.grey[850],),
                      ),
                      title: Text("Adicionar"),
                      onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => ModifyProductsScreen(
                            categoryId: category.documentID
                        )));
                      },
                    )
                  ),
                );
              },
            )
          ],
        ),
      ),

    );
  }
}
