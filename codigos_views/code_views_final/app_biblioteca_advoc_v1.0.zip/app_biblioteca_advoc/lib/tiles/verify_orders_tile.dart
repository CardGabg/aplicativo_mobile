import 'package:appbibliotecaadvoc/widgets/order_header.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class VerifyOrdersTile extends StatelessWidget {

  final DocumentSnapshot order;


  VerifyOrdersTile(this.order);

  final states = [
    "", "Preparação", "Entrega", "Devolução"
  ];


  @override
  Widget build(BuildContext context) {
//    print(order.data["produtos"][0]["product"]["authors"]);
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Card(
        child: ExpansionTile(
          key: Key(order.documentID),
          title: Text("#${order.documentID.substring(order.documentID.length - 7, order.documentID.length)} - "
            "${states[order.data["status"]]}",
          style: TextStyle(color: order.data["status"] != 2 ? Colors.grey[850] : Colors.green),
          ),
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(left: 16, right: 16, top: 6, bottom: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  OrderHeader(order),


                  Column( // Coluna de produtos
                    mainAxisSize: MainAxisSize.min,
//                    children:
//                    order.data["produtos"].map<Widget>((p){
//                      ListTile(
//                        title: Text(p["product"]["title"]), // Nome do livro
//                        subtitle: Text(p["category"] + "/" + p["pid"]), // categoria e id do livro
//                        trailing: Text(p["quantity"].toString(), // quantidade
//                          style: TextStyle(fontSize: 20),
//                        ),
//                        contentPadding: EdgeInsets.zero,
//                      );
//                    }).toList()
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      FlatButton(
                        onPressed: (){
                          Firestore.instance.collection("usuarios").document(order["clienteId"]).collection("pedidos").document(order.documentID).delete();
                          order.reference.delete();
                        },
                        textColor: Colors.red,
                        child: Text("Exclui"),
                      ),
                      FlatButton(
                        onPressed: order.data["status"] > 1 ?  (){
                          order.reference.updateData({"status" : order.data["status"] - 1});
                        }: null,
                        textColor: Colors.grey[850],
                        child: Text("Regredir"),
                      ),
                      FlatButton(
                        onPressed: order.data["status"] < 3 ? (){
                          order.reference.updateData({"status" : order.data["status"] + 1});
                        }: null,
                        textColor: Colors.green,
                        child: Text("Avançar"),
                      ),
                    ],
                  )
                ],
              )
            ),
            ],
          ),
        ),
      );
  }

}

