import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';


class HomeTile extends StatelessWidget {

  HomeTile();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 0.8,
            child: FutureBuilder<QuerySnapshot>(
              future: Firestore.instance.collection("home").getDocuments(),
              builder: (context, snapshot){
                if(!snapshot.hasData)
                  return CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  );
                else {
                  print(snapshot.data.documents.length);
                  return CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  );
                }
              },
//              child: Image.network(
//
//                fit: BoxFit.cover,
//
//              ),
            ),
          )
        ],
      ),
    );
  }
}
