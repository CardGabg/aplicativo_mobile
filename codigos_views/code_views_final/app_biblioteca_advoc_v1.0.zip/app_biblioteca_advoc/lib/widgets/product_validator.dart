class ProductValidator {
  String validateImages(List images){
    if(images.isEmpty) return "Adicione uma imagem do livro";
    return null;
  }
  String validateTitle(String text){
    if(text.isEmpty) return "Preencha o título do livro";
    return null;
  }
  String validateAuthors(String text){
    if(text.isEmpty) return "Coloque o autor do livro";
    return null;
  }
  String validatePublisher(String text){
    if(text.isEmpty) return "Coloque a editora do livro";
    return null;
  }
}