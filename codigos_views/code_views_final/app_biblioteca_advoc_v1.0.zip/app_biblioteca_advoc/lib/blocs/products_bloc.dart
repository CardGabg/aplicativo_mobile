import 'package:bloc_pattern/bloc_pattern.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:rxdart/rxdart.dart';

class ProductBloc extends BlocBase {

  final _dataController = BehaviorSubject<Map>();
  final _loadingController = BehaviorSubject<bool>();
  final _createdController = BehaviorSubject<bool>();

  Stream<Map> get outData => _dataController.stream;
  Stream<bool> get outLoading => _loadingController.stream;
  Stream<bool> get outCreated => _createdController.stream;

  String categoryId;
  DocumentSnapshot product;

  Map<String, dynamic> unsavedData; // Para não prejudicar os dados dos produtos no Firebase, criamos essa lista para criar produtos mas sem alterar nada no banco, só vai alterar quando apertar o botão save

  ProductBloc({this.categoryId, this.product}) {
    if(product != null){ // Se clicar num produto já criado faça
      unsavedData = Map.of(product.data); // clonando os dados daquele produto e transformando num unsavedData, assim a alteração do produto não irá atualizar automaticamente no banco
      unsavedData["imagem"] = List.of(product.data["imagem"]);

      _createdController.add(true);
    } else {
      unsavedData = {
        "titulo": null, "autores": null, "editora": null, "imagem": []
      };
      _createdController.add(false);
    }

    _dataController.add(unsavedData); // Passando os dados do unsavedData pro outData
  }

  void saveTitle(String title){
    unsavedData["titulo"] = title;
  }

  void saveAuthors(String authors){
    unsavedData["autores"] = authors;
  }

  void savePublisher(String publisher){
    unsavedData["editora"] = publisher;
  }

  void saveImages(List images){
    unsavedData["imagem"] = images;
  }

  Future<bool> saveProduct() async {
    _loadingController.add(true);

    try {
      if(product != null){
        await _uploadImages(product.documentID);
        await product.reference.updateData(unsavedData);
      } else {
        DocumentReference dr = await Firestore.instance.collection("produtos").document(categoryId)
            .collection("items").add(Map.from(unsavedData)..remove("imagem"));
        await _uploadImages(dr.documentID);
        await dr.updateData(unsavedData);
      }

      _createdController.add(true);
      _loadingController.add(false);
      return true;

    } catch (e) {
      _loadingController.add(false);
      return true;
    }


  }

  Future _uploadImages(String productId) async {
    for(int i = 0; i < unsavedData["imagem"].length; i++){
      if(unsavedData["imagem"][i] is String) continue;
      
      StorageUploadTask uploadTask = FirebaseStorage.instance.ref().child(categoryId)
          .child(productId).child(DateTime.now().millisecondsSinceEpoch.toString())
          .putFile(unsavedData["imagem"][i]);

      StorageTaskSnapshot s = await uploadTask.onComplete;
      String downloadUrl = await s.ref.getDownloadURL();

      unsavedData["imagem"][i] = downloadUrl;
    }
  }

  void deleteProduct(){
    product.reference.delete();
  }


  @override
  void dispose() {
    _dataController.close();
    _loadingController.close();
    _createdController.close();
  }
}